package agentes;

import jade.core.Agent;


public class Agente_B1 extends Agent {

    @Override
    public void setup() {
        System.out.println("Agente B1 iniciado!");

        addBehaviour(new Comportamento_1(this));

    }
    
   protected void TakeDown(){
       
   }

}
