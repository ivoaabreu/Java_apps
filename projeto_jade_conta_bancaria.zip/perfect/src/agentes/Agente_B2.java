package agentes;

import jade.core.Agent;
import jade.lang.acl.ACLMessage;

public class Agente_B2 extends Agent {

       @Override
    public void setup() {
        System.out.println("Agente B2 iniciado!");
         int step =-1;
       
        addBehaviour(new Comportamento_2(this));
    }
}
