package agentes;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.Scanner;

public class Comportamento_3 extends CyclicBehaviour {

    int conta = 3;
    double saque = 0;
    Scanner s;

    public Comportamento_3(Agent a) {
        super(a);
    }

    @Override
    public void action() {
        ACLMessage msg = getAgent().receive();
        if (msg != null) {
            System.out.println("Agente B3 recebeu: " + msg.getContent());

            s = new Scanner(System.in);
            System.out.println("Digite o número da conta para saldo: ");
            conta = s.nextInt();

            if (conta > 1 || conta < 0 || Comportamento_1.c[conta] == null) {
                ACLMessage reply5 = msg.createReply();
                reply5.setPerformative(ACLMessage.INFORM);
                reply5.setContent(myAgent.getLocalName() + " Conta inválida ou inexistente!");
                myAgent.send(reply5);
               // block();
            } else {

                System.out.println("O seu saldo é de: " + Comportamento_1.c[conta].getSaldo());
                //respondendo agente
                ACLMessage reply3 = msg.createReply();
                reply3.setPerformative(ACLMessage.INFORM);
                reply3.setContent(myAgent.getLocalName() + " informa que o saldo foi exibido com sucesso!");
                myAgent.send(reply3);

            }
      //  block();
        }
        
    }
}
