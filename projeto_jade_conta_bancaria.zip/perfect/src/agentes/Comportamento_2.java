package agentes;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.Scanner;

public class Comportamento_2 extends CyclicBehaviour {

    Scanner s;
    //int verificador = 0;
    int conta = 0;
    double saque = 0;

    public Comportamento_2(Agent a) {
        super(a);
    }

    @Override
    public void action() {
        ACLMessage msg = getAgent().receive();
        if (msg != null) {
            

            if (msg.getContent().contains("Iniciando saque pelo agente B2")) {
                System.out.println("Agente B2 recebeu: " + msg.getContent());

                s = new Scanner(System.in);
                System.out.println("Digite o número da conta para saque: ");
                conta = s.nextInt();
               
                if(conta>1 || conta <0 || Comportamento_1.c[conta] ==null){
                ACLMessage reply4 = msg.createReply();
                reply4.setPerformative(ACLMessage.INFORM);
                reply4.setContent(myAgent.getLocalName() + " Conta inválida ou inexistente!");
                myAgent.send(reply4);
                }block();
                System.out.println("Informe o valor para saque: ");
                saque = s.nextDouble();

                if (saque > Comportamento_1.c[conta].getSaldo()) {
                    System.out.println("Saldo insuficiente!");
                    System.out.println("Informe o valor para saque: ");
                    saque = s.nextDouble();

                } else  {
                    Comportamento_1.c[conta].setSaldo(Comportamento_1.c[conta].getSaldo() - saque);

                    //respondendo agente
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.INFORM);
                    reply.setContent(myAgent.getLocalName() + " informa que o saque foi realizado com sucesso!");
                    myAgent.send(reply);

                }
                
            } else if (msg.getContent().contains("Iniciando depósito pelo agente B2")) {
                System.out.println("Agente B2 recebeu: " + msg.getContent());
                s = new Scanner(System.in);
                System.out.println("Digite o número da conta para depósito: ");
                conta = s.nextInt();
                System.out.println("Informe o valor para depósito: ");
                saque = s.nextDouble();

                Comportamento_1.c[conta].setSaldo(Comportamento_1.c[conta].getSaldo() + saque);
                //respondendo agente
                ACLMessage reply2 = msg.createReply();
                reply2.setPerformative(ACLMessage.INFORM);
                reply2.setContent(myAgent.getLocalName() + " informa que o depósito foi realizado com sucesso!");
                myAgent.send(reply2);
            }
            else{}//----------
             block();
        }
    }
}
