package agentes;

import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import java.util.Scanner;

public class Comportamento_1 extends Behaviour {

    // public static double[] saldo;
    public int step = 0;
    public static Conta[] c = new Conta[2];

    public Comportamento_1(Agent a) {
        super(a);
    }

    @Override
    public void action() {

        //Recepção de mensagens
        //colocar um contains para cada gente pra identificar(ex pergunta no outro agente o numero q ele deseja logo) ex. apos saque o q fazer??manda op para agente1
        ACLMessage msg = getAgent().receive();
        if (msg != null) {
            System.out.println("<--------------------->");
            System.out.println("Agente B1 recebeu: " + msg.getContent());
            System.out.println("<--------------------->");
            step = 0;

        }
        block();

        if (step == 0) {
            Scanner s = new Scanner(System.in);
            System.out.println("Digite o número corresponde a  operação \n"
                    + "1 - Criar conta \n"
                    + "2 - Saque \n"
                    + "3 - Depósito \n"
                    + "4 - Saldo \n"
                    + "5 - Excluir conta \n"
                    + "6 - Sair:"
            );
            step = s.nextInt();

        }
        if (step == 1) {
            int i = 1;
            double saldo_inicial = 0;
            Scanner s1 = new Scanner(System.in);

            for (i = 0; i <= 1; i++) {
                System.out.print("Insira o valor inicial para a " + (i + 1) + "ª conta: ");
                saldo_inicial = s1.nextDouble();
                // saldo[i] = saldo_inicial;
                c[i] = new Conta(saldo_inicial);
                c[i].setSaldo(saldo_inicial);
                System.out.println("Sucesso! O número da sua conta é: " + i + " e tem saldo inicial de R$ " + c[i].getSaldo());
                //c[i] = null;
                step = 0;
            }

            ACLMessage acl6 = new ACLMessage(ACLMessage.INFORM);
            acl6.addReceiver(new AID("Agente1", AID.ISLOCALNAME));
            acl6.setContent("Cadastro realizado por B1");
            myAgent.send(acl6);

        }
        if (step == 2) {

            ACLMessage acl1 = new ACLMessage(ACLMessage.INFORM);
            acl1.addReceiver(new AID("Agente2", AID.ISLOCALNAME));
            acl1.setContent("Iniciando saque pelo agente B2");
            myAgent.send(acl1);

        }
        if (step == 3) {

            ACLMessage acl2 = new ACLMessage(ACLMessage.INFORM);
            acl2.addReceiver(new AID("Agente2", AID.ISLOCALNAME));
            acl2.setContent("Iniciando depósito pelo agente B2");
            myAgent.send(acl2);

        }
        if (step == 4) {

            ACLMessage acl3 = new ACLMessage(ACLMessage.INFORM);
            acl3.addReceiver(new AID("Agente3", AID.ISLOCALNAME));
            acl3.setContent("Iniciando exibição de saldo pelo agente B3");
            myAgent.send(acl3);

        }
        if (step == 5) {
            int conta = -1;
            Scanner s = new Scanner(System.in);
            System.out.println("Digite o número da conta para os dados serem apagados: ");
            conta = s.nextInt();
            c[0].setSaldo(000);
            System.out.println("A conta " + conta + " foi zerada");

            ACLMessage acl7 = new ACLMessage(ACLMessage.INFORM);
            acl7.addReceiver(new AID("Agente1", AID.ISLOCALNAME));
            acl7.setContent("Operação realizada por B1");
            myAgent.send(acl7);

        }
        if (step == 6) {
            step = 7;

        }

    }

    @Override
    public boolean done() {
        return step == 7;
    }

}
