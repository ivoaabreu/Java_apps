
package agentes;

import jade.core.Agent;

/**
 *
 * @author ivo94
 */
public class Agente_B3 extends Agent{
   
    public void setup(){
        System.out.println("Agente B3 iniciado!");
        
        addBehaviour(new Comportamento_3(this));
    }     
}
