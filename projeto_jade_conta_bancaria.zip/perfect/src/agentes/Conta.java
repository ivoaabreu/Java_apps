package agentes;

public class Conta {

    public double saldo;
   
    public Conta(double saldo) {
        this.saldo = saldo;
       }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

}
